<?php

use App\Http\Controllers\Admin\CategoryController as AdminCategoryController;
use App\Http\Controllers\Admin\OrderController as AdminOrderController;
use App\Http\Controllers\Admin\ProductController as AdminProductController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\OrderController as ShopOrderController;
use App\Http\Controllers\ShopController;
use App\Http\Middleware\AdminOnly;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::middleware('web')->group(function () {
    // Shop routes
    Route::get('/', [ShopController::class, 'index'])->name('home');
    Route::get('/shop', [ShopController::class, 'shop'])->name('shop');
    Route::get('/product/{slug}', [ShopController::class, 'product'])->name('product');
    Route::get('/cart', [ShopController::class, 'cart'])->name('cart');
    Route::get('/checkout', [ShopController::class, 'checkout'])->name('checkout');
    Route::get('/categories', [ShopController::class, 'categories'])->name('categories');
    Route::get('/orders/{orderNumber}', [ShopOrderController::class, 'show'])->name('orders.show');

    // Auth routes
    Route::get('/login', fn () => Inertia::render('Auth/Login'))->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::get('/register', fn () => Inertia::render('Auth/Register'))->name('register');
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    // Admin routes - protected
    Route::middleware(['auth', AdminOnly::class])->group(function () {
        Route::get('/admin', fn () => Inertia::render('Admin/Dashboard'))->name('admin.dashboard');
        Route::get('/admin/products', [AdminProductController::class, 'index'])->name('admin.products');
        Route::get('/admin/products/create', [AdminProductController::class, 'create'])->name('admin.products.create');
        Route::post('/admin/products', [AdminProductController::class, 'store'])->name('admin.products.store');
        Route::get('/admin/products/{id}/edit', [AdminProductController::class, 'edit'])->name('admin.products.edit');
        Route::put('/admin/products/{id}', [AdminProductController::class, 'update'])->name('admin.products.update');
        Route::delete('/admin/products/{id}', [AdminProductController::class, 'destroy'])->name('admin.products.destroy');

        Route::get('/admin/orders', [AdminOrderController::class, 'index'])->name('admin.orders');
        Route::get('/admin/orders/{id}', [AdminOrderController::class, 'show'])->name('admin.orders.show');
        Route::put('/admin/orders/{id}', [AdminOrderController::class, 'update'])->name('admin.orders.update');

        Route::get('/admin/categories', [AdminCategoryController::class, 'index'])->name('admin.categories');
        Route::post('/admin/categories', [AdminCategoryController::class, 'store'])->name('admin.categories.store');
        Route::put('/admin/categories/{id}', [AdminCategoryController::class, 'update'])->name('admin.categories.update');
        Route::delete('/admin/categories/{id}', [AdminCategoryController::class, 'destroy'])->name('admin.categories.destroy');
    });
});
