<?php

use App\Http\Controllers\Api\CartController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\ProductController;
use Illuminate\Support\Facades\Route;

Route::get('products', [ProductController::class, 'index']);
Route::get('products/{slug}', [ProductController::class, 'show']);
Route::get('categories', [ProductController::class, 'categories']);

Route::get('cart', [CartController::class, 'index']);
Route::post('cart/add', [CartController::class, 'add']);
Route::patch('cart/{id}', [CartController::class, 'update']);
Route::delete('cart/{id}', [CartController::class, 'remove']);
Route::delete('cart/clear', [CartController::class, 'clear']);
Route::post('cart/coupon', [CartController::class, 'applyCoupon']);
Route::delete('cart/coupon', [CartController::class, 'removeCoupon']);

Route::post('orders', [OrderController::class, 'store']);
Route::get('orders/{orderNumber}', [OrderController::class, 'show']);
