<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Coupon;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class OrderController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'company' => 'nullable|string|max:255',
            'address1' => 'required|string|max:500',
            'address2' => 'nullable|string|max:500',
            'city' => 'required|string|max:255',
            'state' => 'required|string|max:255',
            'postal_code' => 'required|string|max:20',
            'country' => 'required|string|max:255',
            'phone' => 'required|string|max:30',
            'payment_method' => 'required|in:stripe,paypal',
            'items' => 'required|array|min:1',
            'subtotal' => 'required|numeric|min:0',
            'tax' => 'required|numeric|min:0',
            'shipping' => 'required|numeric|min:0',
            'discount' => 'required|numeric|min:0',
            'total' => 'required|numeric|min:0',
            'coupon_id' => 'nullable|exists:coupons,id',
        ]);

        $sessionId = Session::get('cart_session');

        $cartItems = DB::table('cart_items')
            ->where('session_id', $sessionId)
            ->get();

        if ($cartItems->isEmpty()) {
            return response()->json(['message' => 'Cart is empty'], 422);
        }

        $order = DB::transaction(function () use ($validated, $sessionId, $cartItems) {
            $orderNumber = Order::generateOrderNumber();

            $userId = null;

            $order = Order::create([
                'order_number' => $orderNumber,
                'user_id' => $userId,
                'status' => Order::STATUS_PENDING,
                'subtotal' => $validated['subtotal'],
                'tax' => $validated['tax'],
                'shipping' => $validated['shipping'],
                'discount' => $validated['discount'],
                'total' => $validated['total'],
                'coupon_id' => $validated['coupon_id'] ?? null,
                'shipping_name' => "{$validated['first_name']} {$validated['last_name']}",
                'shipping_address' => $validated['address1'].($validated['address2'] ? ", {$validated['address2']}" : ''),
                'shipping_city' => $validated['city'],
                'shipping_state' => $validated['state'],
                'shipping_postal_code' => $validated['postal_code'],
                'shipping_country' => $validated['country'],
                'shipping_phone' => $validated['phone'],
                'payment_method' => $validated['payment_method'],
                'payment_status' => Order::PAYMENT_PENDING,
            ]);

            foreach ($cartItems as $item) {
                $product = Product::find($item->product_id);
                if ($product) {
                    OrderItem::create([
                        'order_id' => $order->id,
                        'product_id' => $product->id,
                        'product_name' => $product->name,
                        'product_sku' => $product->sku,
                        'price' => $product->price,
                        'quantity' => $item->quantity,
                        'subtotal' => $product->price * $item->quantity,
                    ]);

                    $product->decrement('stock', $item->quantity);
                }
            }

            if (! empty($validated['coupon_id'])) {
                Coupon::where('id', $validated['coupon_id'])->increment('used_count');
            }

            DB::table('cart_items')->where('session_id', $sessionId)->delete();
            Session::forget('cart_coupon_id');

            return $order;
        });

        return response()->json([
            'order_number' => $order->order_number,
            'message' => 'Order placed successfully',
        ]);
    }

    public function show($orderNumber)
    {
        $order = Order::with('items', 'coupon')
            ->where('order_number', $orderNumber)
            ->firstOrFail();

        return response()->json($order);
    }
}
