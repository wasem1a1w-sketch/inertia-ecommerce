<template>
    <div>
        <Notifications />
        <!-- Navigation -->
        <header class="bg-white border-b border-gray-100 sticky top-0 z-50">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center h-20">
                    <!-- Logo -->
                    <Link :href="route('home')" class="flex items-center">
                        <span class="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                            Shop
                        </span>
                    </Link>

                    <!-- Desktop Nav -->
                    <nav class="hidden md:flex items-center space-x-8">
                        <Link :href="route('home')" class="nav-link" :class="isActive('/') ? 'nav-link-active' : ''">
                            Home
                        </Link>
                        <Link :href="route('shop')" class="nav-link" :class="isActive('/shop') ? 'nav-link-active' : ''">
                            Shop
                        </Link>
                        <Link :href="route('categories')" class="nav-link" :class="isActive('/categories') ? 'nav-link-active' : ''">
                            Categories
                        </Link>
                    </nav>

                    <!-- Right Side -->
                    <div class="flex items-center space-x-6">
                        <!-- Search -->
                        <Link :href="route('shop')" class="text-gray-400 hover:text-gray-600 transition-colors">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                            </svg>
                        </Link>

                        <!-- Cart -->
                        <Link :href="route('cart')" class="relative text-gray-400 hover:text-indigo-600 transition-colors">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path>
                            </svg>
                            <span v-if="cartStore.itemCount > 0" class="absolute -top-2 -right-2 bg-indigo-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                                {{ cartStore.itemCount }}
                            </span>
                        </Link>

                        <!-- Auth -->
                        <div class="flex items-center space-x-4">
                            <template v-if="user">
                                <span class="text-gray-600 text-sm">{{ user.name }}</span>
                                <Link v-if="isAdmin" :href="route('admin.dashboard')" class="text-indigo-600 hover:text-indigo-700 text-sm">
                                    Admin
                                </Link>
                                <button @click="logout" class="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600">
                                    Logout
                                </button>
                            </template>
                            <template v-else>
                                <Link :href="route('login')" class="text-gray-600 hover:text-indigo-600 font-medium text-sm hidden sm:block">
                                    Sign In
                                </Link>
                                <Link :href="route('register')" class="btn-primary py-2 px-4 text-sm">
                                    Sign Up
                                </Link>
                            </template>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main Content -->
        <main>
            <slot />
        </main>

        <!-- Footer -->
        <footer class="bg-gray-900 text-white py-16 mt-20">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="grid grid-cols-1 md:grid-cols-4 gap-12">
                    <div>
                        <span class="text-2xl font-bold bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
                            Shop
                        </span>
                        <p class="mt-4 text-gray-400 text-sm">Your trusted destination for premium products.</p>
                    </div>
                    <div>
                        <h4 class="font-semibold mb-4">Shop</h4>
                        <ul class="space-y-3 text-gray-400 text-sm">
                            <li><Link :href="route('shop')" class="hover:text-white">All Products</Link></li>
                            <li><Link :href="route('categories')" class="hover:text-white">Categories</Link></li>
                        </ul>
                    </div>
                    <div>
                        <h4 class="font-semibold mb-4">Support</h4>
                        <ul class="space-y-3 text-gray-400 text-sm">
                            <li><a href="#" class="hover:text-white">Contact</a></li>
                            <li><a href="#" class="hover:text-white">Shipping</a></li>
                        </ul>
                    </div>
                    <div>
                        <h4 class="font-semibold mb-4">Newsletter</h4>
                        <form @submit.prevent="subscribe" class="flex">
                            <input v-model="email" type="email" placeholder="Your email" class="bg-gray-800 px-4 py-2 rounded-l-lg text-white w-full focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <button type="submit" class="bg-indigo-600 px-4 py-2 rounded-r-lg hover:bg-indigo-700">Subscribe</button>
                        </form>
                    </div>
                </div>
                <div class="border-t border-gray-800 mt-12 pt-8 text-center text-gray-500 text-sm">
                    &copy; {{ new Date().getFullYear() }} Shop. All rights reserved.
                </div>
            </div>
        </footer>
    </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import { Link, usePage, router } from '@inertiajs/vue3';
import { useCartStore } from '../Stores/cart';
import Notifications from '../components/Notifications.vue';

const page = usePage();
const cartStore = useCartStore();
const email = ref('');

const user = computed(() => page.props.auth?.user);
const isAdmin = computed(() => user.value?.is_admin);

onMounted(async () => {
    await cartStore.fetchCart();
});

function isActive(url) {
    return page.url === url || page.url.startsWith(url);
}

function subscribe() {
    email.value = '';
}

function logout() {
    router.post(route('logout'));
}
</script>