<template>
    <div class="min-h-screen bg-gray-100">
        <!-- Admin Header -->
        <nav class="bg-white shadow-sm">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between h-16">
                    <div class="flex items-center space-x-8">
                        <Link href="/admin" class="flex items-center">
                            <span class="text-xl font-bold text-indigo-600">Admin Panel</span>
                        </Link>
                        <Link href="/admin" class="text-gray-600 hover:text-indigo-600" :class="{ 'text-indigo-600 font-medium': $page.url === '/admin' }">
                            Dashboard
                        </Link>
                        <Link href="/admin/products" class="text-gray-600 hover:text-indigo-600" :class="{ 'text-indigo-600 font-medium': $page.url.startsWith('/admin/products') }">
                            Products
                        </Link>
                        <Link href="/admin/orders" class="text-gray-600 hover:text-indigo-600" :class="{ 'text-indigo-600 font-medium': $page.url.startsWith('/admin/orders') }">
                            Orders
                        </Link>
                        <Link href="/admin/categories" class="text-gray-600 hover:text-indigo-600" :class="{ 'text-indigo-600 font-medium': $page.url.startsWith('/admin/categories') }">
                            Categories
                        </Link>
                    </div>
                    <div class="flex items-center space-x-4">
                        <Link href="/" class="text-gray-600 hover:text-indigo-600 text-sm">View Site</Link>
                        <template v-if="user">
                            <span class="text-gray-600 text-sm">{{ user.name }}</span>
                            <button @click="logout" class="text-red-500 hover:text-red-600 text-sm">Logout</button>
                        </template>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <slot />
        </main>
    </div>
</template>

<script setup>
import { computed } from 'vue';
import { Link, usePage, router } from '@inertiajs/vue3';

const page = usePage();
const user = computed(() => page.props.auth?.user);

function logout() {
    router.post('/logout');
}
</script>