<template>
    <div>
        <!-- Header -->
        <header class="bg-white border-b border-gray-100 sticky top-0 z-50">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between items-center h-20">
                    <Link href="/" class="flex items-center">
                        <span class="text-2xl font-bold text-indigo-600">Shop</span>
                    </Link>
                    <div class="flex items-center space-x-6">
                        <Link href="/cart" class="relative text-gray-600 hover:text-indigo-600">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                            <span v-if="cartStore.itemCount > 0" class="absolute -top-2 -right-2 bg-indigo-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">{{ cartStore.itemCount }}</span>
                        </Link>
                    </div>
                </div>
            </div>
        </header>

        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div class="flex flex-col lg:flex-row gap-8">
                <!-- Sidebar -->
                <aside class="lg:w-64">
                    <div class="bg-white rounded-xl shadow-sm p-6 sticky top-24">
                        <h3 class="font-semibold text-gray-900 mb-4">Categories</h3>
                        <ul class="space-y-2">
                            <li>
                                <Link href="/shop" class="text-indigo-600 font-medium">All Products</Link>
                            </li>
                            <li v-for="category in categories" :key="category.id">
                                <Link :href="`/shop?category=${category.id}`" class="text-gray-600 hover:text-indigo-600">{{ category.name }}</Link>
                            </li>
                        </ul>
                    </div>
                </aside>
                
                <!-- Main Content -->
                <div class="flex-1">
                    <div class="flex justify-between items-center mb-8">
                        <h1 class="text-3xl font-bold text-gray-900">{{ selectedCategoryName || 'All Products' }}</h1>
                        <div class="flex items-center gap-4">
                            <span class="text-sm text-gray-500">{{ products.total || products.length }} products</span>
                            <select v-model="sortBy" @change="loadProducts" class="border rounded-lg px-3 py-2">
                                <option value="newest">Newest</option>
                                <option value="price_low">Price: Low to High</option>
                                <option value="price_high">Price: High to Low</option>
                                <option value="name">Name</option>
                            </select>
                        </div>
                    </div>
                    
                    <div v-if="loading" class="flex justify-center py-12">
                        <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
                    </div>
                    
                    <div v-else-if="(products.data?.length || products.length) === 0" class="text-center py-12 text-gray-500">No products found.</div>
                    
                    <div v-else class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                        <div v-for="product in (products.data || products)" :key="product.id" class="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow overflow-hidden">
                            <Link :href="`/product/${product.slug}`">
                                <div class="aspect-square bg-gray-100 relative">
                                    <img v-if="product.images?.length" :src="`/storage/${product.images[0].image_path}`" :alt="product.name" class="w-full h-full object-cover">
                                    <div v-else class="w-full h-full flex items-center justify-center text-gray-300">
                                        <svg class="w-16 h-16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                    </div>
                                    <span v-if="product.compare_price && product.compare_price > product.price" class="absolute top-3 left-3 bg-red-500 text-white text-xs px-3 py-1 rounded-full">-{{ Math.round((product.compare_price - product.price) / product.compare_price * 100) }}%</span>
                                </div>
                                <div class="p-5">
                                    <p class="text-xs text-gray-500 mb-1">{{ product.category?.name }}</p>
                                    <h3 class="font-semibold text-gray-900 mb-2 line-clamp-2">{{ product.name }}</h3>
                                    <div class="flex items-center gap-2">
                                        <span class="text-xl font-bold text-indigo-600">${{ product.price }}</span>
                                        <span v-if="product.compare_price && product.compare_price > product.price" class="text-sm text-gray-400 line-through">${{ product.compare_price }}</span>
                                    </div>
                                    <p v-if="product.stock <= 0" class="text-xs text-red-500 mt-2">Out of Stock</p>
                                    <p v-else-if="product.stock <= 5" class="text-xs text-orange-500 mt-2">Only {{ product.stock }} left</p>
                                </div>
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { Link, usePage } from '@inertiajs/vue3';
import axios from 'axios';
import { useCartStore } from '../../Stores/cart';

const page = usePage();
const cartStore = useCartStore();
const products = ref({ data: [], total: 0 });
const categories = ref([]);
const loading = ref(true);
const searchQuery = ref('');
const sortBy = ref('newest');
const selectedCategory = ref(null);
const selectedCategoryName = ref('');

onMounted(async () => {
    const urlParams = new URLSearchParams(window.location.search);
    selectedCategory.value = urlParams.get('category');
    await loadCategories();
    await loadProducts();
});

async function loadCategories() {
    try {
        const response = await axios.get('/api/categories');
        categories.value = response.data.data || response.data || [];
    } catch (error) {
        console.error('Failed to load categories:', error);
    }
}

async function loadProducts() {
    loading.value = true;
    try {
        const params = new URLSearchParams();
        if (selectedCategory.value) params.append('category', selectedCategory.value);
        if (searchQuery.value) params.append('search', searchQuery.value);
        if (sortBy.value) params.append('sort', sortBy.value);
        const response = await axios.get(`/api/products?${params.toString()}`);
        products.value = response.data;
        if (selectedCategory.value && categories.value.length) {
            const cat = categories.value.find(c => c.id == selectedCategory.value);
            selectedCategoryName.value = cat?.name || '';
        }
    } catch (error) {
        console.error('Failed to load products:', error);
    } finally {
        loading.value = false;
    }
}
</script>