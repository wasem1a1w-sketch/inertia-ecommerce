<template>
    <div class="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4">
        <div class="max-w-md w-full space-y-8">
            <div>
                <h2 class="text-center text-3xl font-bold">Sign in to your account</h2>
            </div>
            <form class="mt-8 space-y-6" @submit.prevent="submit">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Email</label>
                        <input v-model="form.email" type="email" required
                            class="mt-1 block w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Password</label>
                        <input v-model="form.password" type="password" required
                            class="mt-1 block w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                    </div>
                </div>
                <button type="submit" :disabled="loading"
                    class="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 disabled:opacity-50">
                    {{ loading ? 'Signing in...' : 'Sign in' }}
                </button>
            </form>
            <p class="text-center">
                Don't have an account?
                <Link href="/register" class="text-indigo-600 hover:text-indigo-700">Register</Link>
            </p>
        </div>
    </div>
</template>

<script setup>
import { ref, reactive } from 'vue';
import { Link, router } from '@inertiajs/vue3';
import axios from 'axios';
import { useNotification } from '../../composables/useNotification';

const { error } = useNotification();

const loading = ref(false);
const form = reactive({
    email: '',
    password: '',
});

function submit() {
    loading.value = true;
    axios.post('/login', form).then(res => {
        if (res.data.redirect) {
            window.location.href = res.data.redirect;
        }
    }).catch(() => {
        error('Login failed. Please check your credentials.');
        loading.value = false;
    });
}
</script>