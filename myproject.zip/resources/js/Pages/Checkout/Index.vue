<template>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 class="text-3xl font-bold mb-8">Checkout</h1>
        
        <div v-if="cartStore.items.length === 0" class="text-center py-12">
            <p class="text-gray-500 mb-4">Your cart is empty</p>
            <Link href="/shop" class="inline-block bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700">
                Continue Shopping
            </Link>
        </div>
        
        <div v-else class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div class="lg:col-span-2 space-y-6">
                <div class="bg-white rounded-lg shadow-sm p-6">
                    <h2 class="text-lg font-semibold mb-4">Shipping Information</h2>
                    <form @submit.prevent="placeOrder" class="space-y-4">
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">First Name *</label>
                                <input v-model="form.first_name" type="text" required
                                    class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Last Name *</label>
                                <input v-model="form.last_name" type="text" required
                                    class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Company (optional)</label>
                            <input v-model="form.company" type="text"
                                class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Address *</label>
                            <input v-model="form.address1" type="text" required
                                class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Apartment, suite, etc. (optional)</label>
                            <input v-model="form.address2" type="text"
                                class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">City *</label>
                                <input v-model="form.city" type="text" required
                                    class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">State *</label>
                                <input v-model="form.state" type="text" required
                                    class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                            </div>
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Postal Code *</label>
                                <input v-model="form.postal_code" type="text" required
                                    class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Country *</label>
                                <input v-model="form.country" type="text" required
                                    class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                            </div>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Phone *</label>
                            <input v-model="form.phone" type="tel" required
                                class="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-indigo-500">
                        </div>
                    </form>
                </div>
                
                <div class="bg-white rounded-lg shadow-sm p-6">
                    <h2 class="text-lg font-semibold mb-4">Payment Method</h2>
                    <div class="space-y-3">
                        <label class="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                            <input v-model="form.payment_method" type="radio" value="stripe" class="mr-3">
                            <div>
                                <span class="font-medium">Credit/Debit Card</span>
                                <p class="text-sm text-gray-500">Pay with Stripe</p>
                            </div>
                        </label>
                        <label class="flex items-center p-4 border rounded-lg cursor-pointer hover:bg-gray-50">
                            <input v-model="form.payment_method" type="radio" value="paypal" class="mr-3">
                            <div>
                                <span class="font-medium">PayPal</span>
                                <p class="text-sm text-gray-500">Pay with PayPal</p>
                            </div>
                        </label>
                    </div>
                </div>
            </div>
            
            <div>
                <div class="bg-white rounded-lg shadow-sm p-6 sticky top-24">
                    <h2 class="text-lg font-semibold mb-4">Order Summary</h2>
                    
                    <div class="space-y-3 text-sm mb-4">
                        <div v-for="item in cartStore.items" :key="item.id" class="flex justify-between">
                            <span class="text-gray-600">{{ item.quantity }}x {{ item.product?.name }}</span>
                            <span>${{ (item.product?.price * item.quantity).toFixed(2) }}</span>
                        </div>
                    </div>
                    
                    <div class="border-t pt-3 space-y-2 text-sm">
                        <div class="flex justify-between">
                            <span>Subtotal</span>
                            <span>${{ cartStore.subtotal.toFixed(2) }}</span>
                        </div>
                        <div v-if="cartStore.discount > 0" class="flex justify-between text-green-600">
                            <span>Discount</span>
                            <span>-${{ cartStore.discount.toFixed(2) }}</span>
                        </div>
                        <div class="flex justify-between">
                            <span>Tax</span>
                            <span>${{ cartStore.tax.toFixed(2) }}</span>
                        </div>
                        <div class="flex justify-between">
                            <span>Shipping</span>
                            <span>{{ cartStore.shipping === 0 ? 'FREE' : '$' + cartStore.shipping.toFixed(2) }}</span>
                        </div>
                        <div class="border-t pt-2 flex justify-between font-bold text-lg">
                            <span>Total</span>
                            <span>${{ cartStore.total.toFixed(2) }}</span>
                        </div>
                    </div>
                    
                    <button @click="placeOrder" :disabled="placing"
                        class="w-full bg-indigo-600 text-white py-3 rounded-lg font-semibold hover:bg-indigo-700 disabled:opacity-50 mt-6">
                        {{ placing ? 'Processing...' : 'Place Order' }}
                    </button>
                    
                    <p v-if="error" class="text-red-500 text-sm mt-2">{{ error }}</p>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
import { ref, reactive } from 'vue';
import { Link, usePage } from '@inertiajs/vue3';
import { useCartStore } from '../../Stores/cart';
import axios from 'axios';

const page = usePage();
const cartStore = useCartStore();
const placing = ref(false);
const error = ref('');

const form = reactive({
    first_name: page.props.auth?.user?.first_name || '',
    last_name: page.props.auth?.user?.last_name || '',
    company: '',
    address1: '',
    address2: '',
    city: '',
    state: '',
    postal_code: '',
    country: '',
    phone: page.props.auth?.user?.phone || '',
    payment_method: 'stripe',
});

async function placeOrder() {
    placing.value = true;
    error.value = '';
    
    try {
        const response = await axios.post('/api/orders', {
            ...form,
            items: cartStore.items,
            coupon_id: cartStore.coupon?.id,
            subtotal: cartStore.subtotal,
            tax: cartStore.tax,
            shipping: cartStore.shipping,
            discount: cartStore.discount,
            total: cartStore.total,
        });
        
        await cartStore.clearCart();
        
        window.location.href = `/orders/${response.data.order_number}`;
    } catch (err) {
        error.value = err.response?.data?.message || 'Failed to place order. Please try again.';
    } finally {
        placing.value = false;
    }
}
</script>