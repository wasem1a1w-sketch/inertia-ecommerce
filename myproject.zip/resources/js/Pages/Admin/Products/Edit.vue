<template>
    <div class="min-h-screen bg-gray-100">
        <nav class="bg-white shadow-sm">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between h-16">
                    <div class="flex">
                        <Link :href="route('admin.dashboard')" class="flex-shrink-0 flex items-center">
                            <span class="text-xl font-bold text-indigo-600">Admin Panel</span>
                        </Link>
                    </div>
                </div>
            </div>
        </nav>

        <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <div class="px-4 py-6 sm:px-0">
                <h1 class="text-2xl font-bold mb-6">Edit Product</h1>
                
                <form @submit.prevent="submit" class="bg-white shadow overflow-hidden sm:rounded-lg p-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Name *</label>
                            <input v-model="form.name" type="text" required class="mt-1 block w-full border rounded-md px-3 py-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Slug *</label>
                            <input v-model="form.slug" type="text" required class="mt-1 block w-full border rounded-md px-3 py-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Price *</label>
                            <input v-model="form.price" type="number" step="0.01" required class="mt-1 block w-full border rounded-md px-3 py-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Compare Price</label>
                            <input v-model="form.compare_price" type="number" step="0.01" class="mt-1 block w-full border rounded-md px-3 py-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Stock *</label>
                            <input v-model="form.stock" type="number" required class="mt-1 block w-full border rounded-md px-3 py-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Category</label>
                            <select v-model="form.category_id" class="mt-1 block w-full border rounded-md px-3 py-2">
                                <option value="">Select category</option>
                                <option v-for="cat in categories" :key="cat.id" :value="cat.id">{{ cat.name }}</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">SKU</label>
                            <input v-model="form.sku" type="text" class="mt-1 block w-full border rounded-md px-3 py-2">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Weight</label>
                            <input v-model="form.weight" type="number" class="mt-1 block w-full border rounded-md px-3 py-2">
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700">Short Description</label>
                            <textarea v-model="form.short_description" rows="2" class="mt-1 block w-full border rounded-md px-3 py-2"></textarea>
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700">Description</label>
                            <textarea v-model="form.description" rows="4" class="mt-1 block w-full border rounded-md px-3 py-2"></textarea>
                        </div>
                        <div class="md:col-span-2 flex gap-6">
                            <label class="flex items-center">
                                <input v-model="form.is_active" type="checkbox" class="mr-2">
                                <span class="text-sm text-gray-700">Active</span>
                            </label>
                            <label class="flex items-center">
                                <input v-model="form.is_featured" type="checkbox" class="mr-2">
                                <span class="text-sm text-gray-700">Featured</span>
                            </label>
                        </div>
                    </div>
                    <div class="mt-6 flex gap-4">
                        <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700">
                            Update Product
                        </button>
                        <Link :href="route('admin.products')" class="text-gray-700 px-6 py-2 border rounded-lg hover:bg-gray-50">
                            Cancel
                        </Link>
                    </div>
                </form>
            </div>
        </main>
    </div>
</template>

<script setup>
import { reactive, onMounted } from 'vue';
import { Link, router } from '@inertiajs/vue3';
import { useNotification } from '../../../composables/useNotification';

const { success, error } = useNotification();

const props = defineProps({ product: Object, categories: Array });

const form = reactive({ ...props.product });

function submit() {
    router.put(route('admin.products.update', { id: props.product.id }), form, {
        onSuccess: () => {
            success('Product updated successfully!');
            router.visit(route('admin.products'));
        },
    });
}
</script>