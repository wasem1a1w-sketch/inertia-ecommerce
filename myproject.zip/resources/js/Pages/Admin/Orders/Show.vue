<template>
    <div class="min-h-screen bg-gray-100">
        <nav class="bg-white shadow-sm">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between h-16">
                    <div class="flex">
                        <Link :href="route('admin.dashboard')" class="flex-shrink-0 flex items-center">
                            <span class="text-xl font-bold text-indigo-600">Admin Panel</span>
                        </Link>
                    </div>
                </div>
            </div>
        </nav>

        <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <div class="px-4 py-6 sm:px-0">
                <div class="flex justify-between items-center mb-6">
                    <h1 class="text-2xl font-bold">Order {{ order.order_number }}</h1>
                    <Link :href="route('admin.orders')" class="text-indigo-600 hover:text-indigo-700">Back to Orders</Link>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="bg-white shadow overflow-hidden sm:rounded-lg p-6">
                        <h3 class="text-lg font-medium mb-4">Order Details</h3>
                        <form @submit.prevent="updateOrder">
                            <div class="mb-4">
                                <label class="block text-sm font-medium text-gray-700">Status</label>
                                <select v-model="form.status" class="mt-1 block w-full border rounded-md px-3 py-2">
                                    <option value="pending">Pending</option>
                                    <option value="processing">Processing</option>
                                    <option value="shipped">Shipped</option>
                                    <option value="delivered">Delivered</option>
                                    <option value="cancelled">Cancelled</option>
                                </select>
                            </div>
                            <div class="mb-4">
                                <label class="block text-sm font-medium text-gray-700">Payment Status</label>
                                <select v-model="form.payment_status" class="mt-1 block w-full border rounded-md px-3 py-2">
                                    <option value="pending">Pending</option>
                                    <option value="paid">Paid</option>
                                    <option value="failed">Failed</option>
                                    <option value="refunded">Refunded</option>
                                </select>
                            </div>
                            <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">Update</button>
                        </form>
                    </div>

                    <div class="bg-white shadow overflow-hidden sm:rounded-lg p-6">
                        <h3 class="text-lg font-medium mb-4">Shipping Address</h3>
                        <p>{{ order.shipping_name }}</p>
                        <p>{{ order.shipping_address }}</p>
                        <p>{{ order.shipping_city }}, {{ order.shipping_state }} {{ order.shipping_postal_code }}</p>
                        <p>{{ order.shipping_country }}</p>
                        <p>{{ order.shipping_phone }}</p>
                    </div>
                </div>

                <div class="bg-white shadow overflow-hidden sm:rounded-lg mt-6">
                    <div class="px-6 py-4 border-b border-gray-200">
                        <h3 class="text-lg font-medium">Order Items</h3>
                    </div>
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Qty</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <tr v-for="item in order.items" :key="item.id">
                                <td class="px-6 py-4">{{ item.product_name }}</td>
                                <td class="px-6 py-4">${{ item.price }}</td>
                                <td class="px-6 py-4">{{ item.quantity }}</td>
                                <td class="px-6 py-4">${{ item.subtotal }}</td>
                            </tr>
                        </tbody>
                        <tfoot class="bg-gray-50">
                            <tr>
                                <td colspan="3" class="px-6 py-3 text-right font-medium">Subtotal</td>
                                <td class="px-6 py-3">${{ order.subtotal }}</td>
                            </tr>
                            <tr>
                                <td colspan="3" class="px-6 py-3 text-right font-medium">Tax</td>
                                <td class="px-6 py-3">${{ order.tax }}</td>
                            </tr>
                            <tr>
                                <td colspan="3" class="px-6 py-3 text-right font-medium">Shipping</td>
                                <td class="px-6 py-3">${{ order.shipping }}</td>
                            </tr>
                            <tr v-if="order.discount > 0">
                                <td colspan="3" class="px-6 py-3 text-right font-medium text-green-600">Discount</td>
                                <td class="px-6 py-3 text-green-600">-${{ order.discount }}</td>
                            </tr>
                            <tr>
                                <td colspan="3" class="px-6 py-3 text-right font-bold">Total</td>
                                <td class="px-6 py-3 font-bold">${{ order.total }}</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </main>
    </div>
</template>

<script setup>
import { reactive } from 'vue';
import { Link, router } from '@inertiajs/vue3';

const props = defineProps({ order: Object });

const form = reactive({
    status: props.order.status,
    payment_status: props.order.payment_status,
});

function updateOrder() {
    router.put(route('admin.orders.update', { id: props.order.id }), form, {
        onSuccess: () => {
            alert('Order updated');
        },
    });
}
</script>