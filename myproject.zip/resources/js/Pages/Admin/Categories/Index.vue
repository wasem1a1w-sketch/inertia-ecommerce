<template>
    <div class="min-h-screen bg-gray-100">
        <nav class="bg-white shadow-sm">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex justify-between h-16">
                    <div class="flex">
                        <Link href="/admin" class="flex-shrink-0 flex items-center">
                            <span class="text-xl font-bold text-indigo-600">Admin Panel</span>
                        </Link>
                    </div>
                    <div class="flex items-center">
                        <Link href="/" class="text-gray-500 hover:text-gray-700">View Store</Link>
                    </div>
                </div>
            </div>
        </nav>

        <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <div class="px-4 py-6 sm:px-0">
                <div class="flex justify-between items-center mb-6">
                    <h1 class="text-2xl font-bold">Categories</h1>
                </div>

                <div class="bg-white shadow overflow-hidden sm:rounded-lg mb-6 p-6">
                    <h3 class="text-lg font-medium mb-4">Add Category</h3>
                    <form @submit.prevent="createCategory" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <input v-model="form.name" type="text" placeholder="Name" required class="border rounded-md px-3 py-2">
                        <input v-model="form.slug" type="text" placeholder="Slug" required class="border rounded-md px-3 py-2">
                        <input v-model="form.description" type="text" placeholder="Description" class="border rounded-md px-3 py-2">
                        <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700">Add</button>
                    </form>
                </div>

                <div class="bg-white shadow overflow-hidden sm:rounded-lg">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Name</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Slug</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Products</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <tr v-for="category in categories" :key="category.id">
                                <td class="px-6 py-4 text-sm font-medium text-gray-900">{{ category.name }}</td>
                                <td class="px-6 py-4 text-sm text-gray-500">{{ category.slug }}</td>
                                <td class="px-6 py-4 text-sm text-gray-500">{{ category.products_count }}</td>
                                <td class="px-6 py-4 text-right text-sm font-medium">
                                    <button @click="deleteCategory(category.id)" class="text-red-600 hover:text-red-900">Delete</button>
                                </td>
                            </tr>
                            <tr v-if="categories.length === 0">
                                <td colspan="4" class="px-6 py-4 text-center text-sm text-gray-500">No categories</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</template>

<script setup>
import { reactive } from 'vue';
import { Link } from '@inertiajs/vue3';
import axios from 'axios';

defineProps({ categories: Array });

const form = reactive({ name: '', slug: '', description: '' });

async function createCategory() {
    await axios.post('/admin/categories', form);
    window.location.reload();
}

async function deleteCategory(id) {
    if (confirm('Delete this category?')) {
        await axios.delete(`/admin/categories/${id}`);
        window.location.reload();
    }
}
</script>