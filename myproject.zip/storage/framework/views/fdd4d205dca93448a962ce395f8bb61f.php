<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(config('app.name', 'Laravel')); ?></title>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body>
        <?php if(request()->is('admin*')): ?>
            <nav class="bg-white shadow-sm border-b">
                <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div class="flex justify-between h-16">
                        <div class="flex items-center space-x-8">
                            <a href="/admin" class="flex items-center">
                                <span class="text-xl font-bold text-indigo-600">Admin Panel</span>
                            </a>
                            <a href="/admin" class="text-gray-600 hover:text-indigo-600 <?php echo e(request()->is('admin') ? 'text-indigo-600 font-medium' : ''); ?>">Dashboard</a>
                            <a href="/admin/products" class="text-gray-600 hover:text-indigo-600 <?php echo e(request()->is('admin/products*') ? 'text-indigo-600 font-medium' : ''); ?>">Products</a>
                            <a href="/admin/orders" class="text-gray-600 hover:text-indigo-600 <?php echo e(request()->is('admin/orders*') ? 'text-indigo-600 font-medium' : ''); ?>">Orders</a>
                            <a href="/admin/categories" class="text-gray-600 hover:text-indigo-600 <?php echo e(request()->is('admin/categories*') ? 'text-indigo-600 font-medium' : ''); ?>">Categories</a>
                        </div>
                        <div class="flex items-center space-x-4">
                            <a href="/" class="text-gray-600 hover:text-indigo-600 text-sm">View Site</a>
                            <?php if(auth()->guard()->check()): ?>
                                <span class="text-gray-600 text-sm"><?php echo e(auth()->user()->name); ?></span>
                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="text-red-500 hover:text-red-600 text-sm">Logout</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </nav>
        <?php endif; ?>
        <?php $__inertiaSsrResponse = app(\Inertia\Ssr\SsrState::class)->setPage($page)->dispatch();  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><script data-page="app" type="application/json"><?php echo json_encode($page); ?></script><div id="app"></div><?php } ?>
    </body>
</html><?php /**PATH /var/www/html/myproject/resources/views/app.blade.php ENDPATH**/ ?>