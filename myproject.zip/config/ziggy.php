<?php

return [
    'url' => 'http://localhost/myproject/public',
    'group' => null,
    'bindings' => [],
];
